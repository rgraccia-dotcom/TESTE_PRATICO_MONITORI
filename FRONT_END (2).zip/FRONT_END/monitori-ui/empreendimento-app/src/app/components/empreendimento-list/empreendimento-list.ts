import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';

import { Empreendimento } from '../../models/empreendimento';
import { EmpreendimentoService } from '../../services/empreendimento';
import { ChangeDetectorRef } from '@angular/core';


@Component({
  selector: 'app-empreendimento-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './empreendimento-list.html',
  styleUrls: ['./empreendimento-list.scss']
})
export class EmpreendimentoListComponent implements OnInit {

  empreendimentos: Empreendimento[] = [];

  filtroNome = '';
  filtroStatus: boolean | null = null;

  carregando = false;

  constructor(
    private empreendimentoService: EmpreendimentoService,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    console.log('Carregando lista...');
    this.carregarTodos();
  }

carregarTodos(): void {

  this.carregando = true;

  this.empreendimentoService
    .getListAll()
    .pipe(
      finalize(() => {
        this.carregando = false;
      })
    )
    .subscribe({
      next: (retorno) => {

        console.log('Dados recebidos:', retorno);

        this.empreendimentos = [];
        this.empreendimentos = structuredClone(retorno);

        this.carregando = false;

        this.cd.detectChanges();
        

      },
      error: (erro) => {
        console.error('Erro ao carregar empreendimentos', erro);
      }
    });
}

  pesquisar(): void {

    this.carregando = true;

    this.empreendimentoService
      .getList(
        this.filtroNome?.trim(),
        this.filtroStatus ?? undefined
      )
      .pipe(
        finalize(() => {
          this.carregando = false;
        })
      )
      .subscribe({
        next: (retorno) => {

          this.empreendimentos = [];
          this.empreendimentos = [...retorno];

          this.carregando = false;

          this.cd.detectChanges();

          

        },
        error: (erro) => {
          console.error('Erro ao pesquisar empreendimentos', erro);
        }
      });
  }

  limparFiltros(): void {

    this.filtroNome = '';
    this.filtroStatus = null;

    this.carregarTodos();
  }

  novo(): void {
    this.router.navigate(['/empreendimento/novo']);
  }

  dashboard(): void {
    this.router.navigate(['/dashboard']);
  }


ordemDataAsc = false;

ordenarPorData(): void {

  this.ordemDataAsc = !this.ordemDataAsc;

  this.empreendimentos.sort((a, b) => {

    const dataA = new Date(a.dataCriacao).getTime();
    const dataB = new Date(b.dataCriacao).getTime();

    return this.ordemDataAsc
      ? dataA - dataB   // mais antiga → mais nova
      : dataB - dataA;  // mais nova → mais antiga

  });

}

ordemNomeAsc = false;

ordenarPorNome(): void {

  this.ordemNomeAsc = !this.ordemNomeAsc;

  this.empreendimentos.sort((a, b) => {

    const nomeA = (a.nome || '').toLowerCase();
    const nomeB = (b.nome || '').toLowerCase();

    if (nomeA < nomeB) {
      return this.ordemNomeAsc ? -1 : 1;
    }

    if (nomeA > nomeB) {
      return this.ordemNomeAsc ? 1 : -1;
    }

    return 0;
  });

}

  editar(item: Empreendimento): void {
    this.router.navigate(['/empreendimento/editar', item.id]);
  }

  excluir(id: number): void {

    if (!confirm('Deseja excluir este empreendimento?')) {
      return;
    }

    this.carregando = true;

    this.empreendimentoService
      .delete(id)
      .pipe(
        finalize(() => {
          this.carregando = false;
        })
      )
      .subscribe({
        next: () => {

          if (
            this.filtroNome.trim() ||
            this.filtroStatus !== null
          ) {
            this.pesquisar();
          } else {
            this.carregarTodos();
          }

        },
        error: (erro) => {
          console.error('Erro ao excluir empreendimento', erro);
        }
      });
  }
}