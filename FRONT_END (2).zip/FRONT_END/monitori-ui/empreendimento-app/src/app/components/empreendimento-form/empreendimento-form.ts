import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { EmpreendimentoService } from '../../services/empreendimento';
import { Empreendimento } from '../../models/empreendimento';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-empreendimento-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './empreendimento-form.html',
  styleUrls: ['./empreendimento-form.scss']
})
export class EmpreendimentoFormComponent implements OnInit {

  empreendimento: Empreendimento = {
    id: 0,
    nome: '',
    endereco: '',
    cnpj: '',
    status: 'A',
    dataCriacao: new Date()
  };

  bloqueado = false;

  constructor(
    private empreendimentoService: EmpreendimentoService,
    private router: Router,
    private route: ActivatedRoute,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {

    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id) {
      return;
    }
    this.empreendimentoService.getById(id)
      .subscribe({
        next: (dados) => {

          this.empreendimento = dados;

          this.cd.detectChanges();

          // aplica máscara ao carregar
          this.formatarCnpj();

          // se estiver inativo não permite edição
          if (dados.status === 'I') {
            this.bloqueado = true;
            alert('Este empreendimento está inativo e não pode ser editado.');
          }
        },
        error: (erro) => {
          console.error(erro);
          alert('Erro ao carregar empreendimento.');
          this.router.navigate(['/']);
        }
      });
  }

salvar(): void {

  debugger

  if (this.bloqueado) {
    alert('Empreendimento inativo não pode ser alterado.');
    return;
  }

  // Remove máscara do CNPJ
  if (this.empreendimento.cnpj) {
    this.empreendimento.cnpj =
      this.empreendimento.cnpj.replace(/\D/g, '');
  }

  // EDITAR (update)
  if (this.empreendimento.id && this.empreendimento.id > 0) {

    this.empreendimento.status = this.empreendimento.status? 'A':'I'; 
  
    this.empreendimentoService.update(this.empreendimento)
      .subscribe({
        next: () => {
          alert('Atualizado com sucesso!');
          this.router.navigate(['/']);
        },
        error: (erro) => {
          console.error(erro);
          alert('Erro ao atualizar');
        }
      });

    return;
  }

  // NOVO (insert)
  this.empreendimentoService.save(this.empreendimento)
    .subscribe({
      next: () => {
        alert('Salvo com sucesso!');
        this.router.navigate(['/']);
      },
      error: (erro) => {
        console.error(erro);
        alert('Erro ao salvar');
      }
    });
}

  formatarCnpj(): void {

    let cnpj = this.empreendimento.cnpj || '';

    cnpj = cnpj.replace(/\D/g, '');

    cnpj = cnpj.substring(0, 14);

    cnpj = cnpj
      .replace(/^(\d{2})(\d)/, '$1.$2')
      .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
      .replace(/\.(\d{3})(\d)/, '.$1/$2')
      .replace(/(\d{4})(\d)/, '$1-$2');

    this.empreendimento.cnpj = cnpj;
  }

  cancelar(): void {
    this.router.navigate(['/']);
  }
}