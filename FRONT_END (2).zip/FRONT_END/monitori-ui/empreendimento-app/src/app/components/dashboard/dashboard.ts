import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js/auto';
import { EmpreendimentoService } from '../../services/empreendimento';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss']
})
export class DashboardComponent implements OnInit {

  constructor(
    private empreendimentoService: EmpreendimentoService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.carregarDados();
  }

  carregarDados(): void {

    this.empreendimentoService.getListAll().subscribe((dados) => {

      const ativos = dados.filter(e => e.status === 'A').length;
      const inativos = dados.filter(e => e.status === 'I').length;

      this.criarGrafico(ativos, inativos);

    });

  }

  criarGrafico(ativos: number, inativos: number): void {

    new Chart('graficoEmpreendimentos', {
      type: 'pie',
      data: {
        labels: ['Empreendimentos Ativos', 'Empreendimentos Inativos'],
        datasets: [{
          data: [ativos, inativos],
          backgroundColor: ['#28a745', '#dc3545']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

  }

  irParaListaEmpreendimentos(): void {
    this.router.navigate(['/']);
  }

}
