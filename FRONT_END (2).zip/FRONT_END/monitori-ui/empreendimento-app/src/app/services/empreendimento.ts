import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Empreendimento } from '../models/empreendimento';


import {
  HttpClient,
  HttpErrorResponse,
  HttpParams
} from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmpreendimentoService {

  private apiUrl = 'http://localhost:7205/Empreendimento';

  constructor(private http: HttpClient) { }

getListAll(): Observable<Empreendimento[]> {
  return this.http
    .get<Empreendimento[]>(
      `${this.apiUrl}/GetListAll`
    )
    .pipe(
      catchError((error: HttpErrorResponse) => {
        this.handleError(error);
        return throwError(() => error);
      })
    );
}

getById(id: number): Observable<Empreendimento> {
  return this.http
    .get<Empreendimento>(
      `${this.apiUrl}/GetById/${id}`
    )
    .pipe(
      catchError((error: HttpErrorResponse) => {
        this.handleError(error);
        return throwError(() => error);
      })
    );
}

getList(
  nome?: string,
  status?: boolean
): Observable<Empreendimento[]> {

  let params = new HttpParams();

  if (nome?.trim()) {
    params = params.set('nome', nome.trim());
  }

  if (status !== undefined && status !== null) {
    params = params.set(
      'status',
      status ? 'A' : 'I'
    );
  }

  return this.http
    .get<Empreendimento[]>(
      `${this.apiUrl}/GetList`,
      { params }
    )
    .pipe(
      catchError((error: HttpErrorResponse) => {
        this.handleError(error);
        return throwError(() => error);
      })
    );
}

private handleError(
  error: HttpErrorResponse
): void {

  console.log('Status:', error.status);
  console.log('Mensagem:', error.message);
  console.log('Erro completo:', error);

  if (error.status === 0) {
    console.error(
      'Falha de conexão, CORS, HTTPS ou API indisponível.'
    );
  }
}

  save(model: Empreendimento): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/Save`,
      model
    );
  }

  update(model: Empreendimento): Observable<any> {


    return this.http.put(
      `${this.apiUrl}/Update`,
      model
    );
  }

  delete(id: number): Observable<any> {
    return this.http.delete(
      `${this.apiUrl}/Delete/${id}`
    );
  }
}
