
import { Routes } from '@angular/router';

import { EmpreendimentoListComponent } from './components/empreendimento-list/empreendimento-list';
import { EmpreendimentoFormComponent } from './components/empreendimento-form/empreendimento-form';
import { DashboardComponent } from './components/dashboard/dashboard';

export const routes: Routes = [
  {
    path: '',
    component: EmpreendimentoListComponent
  },

  {
    path: 'empreendimento/novo',
    component: EmpreendimentoFormComponent
  },
  {
    path: 'empreendimento/editar/:id',
    component: EmpreendimentoFormComponent
  },
  { 
    path: 'dashboard', 
    component: DashboardComponent 
  }

];
