export interface Empreendimento {
  id: number;
  cnpj: string;
  nome: string;
  endereco: string;
  status: string;
  dataCriacao:Date;
}