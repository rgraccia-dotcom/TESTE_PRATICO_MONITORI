﻿using Monitory.TestePratico.Repository.Entity;
using Microsoft.EntityFrameworkCore;

namespace Monitory.TestePratico.Repository
{
    public partial class OrionDbContext : DbContext
    {
        public OrionDbContext(DbContextOptions<OrionDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<TbEmpreendimento> TbEmpreendimento { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TbEmpreendimento>(entity =>
            {
                entity.HasKey(e => e.IdEmpreendimento)
                      .HasName("PK_Empreendimento");

                entity.ToTable("TbEmpreendimento");

                entity.HasIndex(e => e.Cnpj, "UQ_Empreendimento_CNPJ")
                      .IsUnique();

                entity.Property(e => e.IdEmpreendimento)
                      .HasColumnName("IdEmpreendimento");

                entity.Property(e => e.Cnpj)
                      .HasMaxLength(14)
                      .IsUnicode(false)
                      .HasColumnName("Cnpj");

                entity.Property(e => e.Nome)
                      .HasMaxLength(200)
                      .IsUnicode(false)
                      .HasColumnName("Nome");

                entity.Property(e => e.Endereco)
                      .HasMaxLength(300)
                      .IsUnicode(false)
                      .HasColumnName("Endereco");

                entity.Property(e => e.Status)
                      .HasMaxLength(1)
                      .IsFixedLength()
                      .IsUnicode(false)
                      .HasColumnName("Status");

                entity.Property(e => e.DataCriacao)
                      .HasColumnType("datetime")
                      .HasColumnName("DataCriacao");
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
