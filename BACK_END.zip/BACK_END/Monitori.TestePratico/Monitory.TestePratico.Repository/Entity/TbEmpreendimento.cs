﻿namespace Monitory.TestePratico.Repository.Entity
{
    public partial class TbEmpreendimento
    {
        public int IdEmpreendimento { get; set; }

        public string Cnpj { get; set; }

        public string? Nome { get; set; }

        public string? Endereco { get; set; }

        public char Status { get; set; }

        public DateTime? DataCriacao { get; set; }


    }
}