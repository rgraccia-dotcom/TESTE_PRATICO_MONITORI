﻿using System.Globalization;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Text;

namespace Monitori.TestePratico.Tools
{
    public static partial class Converters
    {

        /// <summary>
        /// Calculates diurnal time between two DateTime
        /// </summary>
        /// <param name="init">The init date time</param>
        /// <param name="end">The end date time</param>
        /// <returns>The diurnal time</returns>
        public static TimeSpan CalculateDiurnalTime(this DateTime init, DateTime end, int startDiurnalTime = 6, int endDiurnalTime = 21)
        {
            if (init.TimeOfDay < TimeSpan.FromHours(startDiurnalTime))
            {
                if (end.TimeOfDay < TimeSpan.FromHours(startDiurnalTime))
                    return TimeSpan.Zero;
                else if (end.TimeOfDay < TimeSpan.FromHours(endDiurnalTime))
                    return end.TimeOfDay - TimeSpan.FromHours(startDiurnalTime);
                else
                    return TimeSpan.FromHours(15);
            }
            else if (init.TimeOfDay < TimeSpan.FromHours(endDiurnalTime))
            {
                if (end.TimeOfDay < TimeSpan.FromHours(startDiurnalTime))
                    return TimeSpan.FromHours(endDiurnalTime) - init.TimeOfDay;
                else if (end.TimeOfDay < TimeSpan.FromHours(endDiurnalTime))
                    return end - init;
                else
                    return TimeSpan.FromHours(endDiurnalTime) - init.TimeOfDay;
            }
            else
            {
                if (end.TimeOfDay < TimeSpan.FromHours(startDiurnalTime))
                    return TimeSpan.Zero;
                else if (end.TimeOfDay < TimeSpan.FromHours(endDiurnalTime))
                    return end.TimeOfDay - TimeSpan.FromHours(startDiurnalTime);
                else
                    return TimeSpan.Zero;
            }
        }

        public static string FormatDate(string date)
        {
            if (date != null)
            {
                string[] split;
                DateTime dateFinal;
                // DATA SEPARADAS POR / EXEMPLO: DD/MM/YYYY
                if (date.IndexOf('/') > 0)
                {
                    split = date.Split('/');
                }
                // DATAS SEPARADAS POR - EXEMPLO: DD-MM-YYYY
                else if (date.IndexOf('-') > 0)
                {
                    split = date.Split('-');
                }
                else
                {
                    //FORMATO NÃO PREVISTO
                    split = new string[0];
                }
                // FORMATO DD MM YYYY OU MM DD YYYY
                if (split.Length == 3 && split[2].Length == 4)
                {
                    // AQUI PODE ADICIONAR IF PARA INVERTER O DIA COM O MÊS NO INGLÊS
                    var dayOrMonth = ConvertToInt(split[0]);
                    var monthOrDay = ConvertToInt(split[1]);
                    var year = ConvertToInt(split[2]);

                    dateFinal = ConvertToDateTime(dayOrMonth, monthOrDay, year);
                }
                // FORMATO YYYY MM DD OU YYYY DD MM
                else if (split.Length == 3 && split[0].Length == 4)
                {
                    // AQUI PODE ADICIONAR IF PARA INVERTER O DIA COM O MÊS NO INGLÊS
                    var dayOrMonth = ConvertToInt(split[2]);
                    var monthOrDay = ConvertToInt(split[1]);
                    var year = ConvertToInt(split[0]);

                    dateFinal = ConvertToDateTime(dayOrMonth, monthOrDay, year);
                }
                else
                {
                    //FORMATO NÃO PREVISTO
                    dateFinal = DateTime.Now;
                }
                return ($"{dateFinal.ToString("yyyy-MM-dd")}");
            }
            else
            {
                DateTime dateFinal;
                dateFinal = DateTime.Now;
                return ($"{dateFinal.ToString("yyyy-MM-dd")}");
            }
        }

        private static int ConvertToInt(string number)
        {
            var outNumber = 0;
            Int32.TryParse(number, out outNumber);
            return outNumber;
        }

        private static DateTime ConvertToDateTime(int dayOrMonth, int monthOrDay, int year)
        {
            try
            {
                return new DateTime(year, monthOrDay, dayOrMonth);
            }
            catch
            {
                return new DateTime(year, dayOrMonth, monthOrDay);
            }
        }

        public static string? RemoveDuplicatedWhiteSpaces(this string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            while (text.Contains("  "))
            {
                text = text.Replace("  ", " ");
            }
            return text;
        }

    }
}
