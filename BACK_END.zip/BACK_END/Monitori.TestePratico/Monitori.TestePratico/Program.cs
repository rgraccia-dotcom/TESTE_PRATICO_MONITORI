using Microsoft.EntityFrameworkCore;
using Monitori.TestePratico.Business.Empreendimento;
using Monitori.TestePratico.Business;
using Monitory.TestePratico.Repository;

var builder = WebApplication.CreateBuilder(args);

// Configure Database (PEGA DO appsettings.json)
var sqlConn = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<OrionDbContext>(options =>
    options.UseSqlServer(sqlConn)
);

// Add services to the container
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngular", policy =>
    {
        policy
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});

// DI
builder.Services.AddScoped<IEmpreendimentoBO, EmpreendimentoBO>();

var app = builder.Build();

app.UseCors("AllowAngular");

// Swagger
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
