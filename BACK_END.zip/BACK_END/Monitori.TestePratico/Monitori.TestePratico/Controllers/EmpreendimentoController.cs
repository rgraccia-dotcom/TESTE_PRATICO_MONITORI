using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Monitori.TestePratico.Business;
using Monitori.TestePratico.Model.Empreendimento;

namespace Monitori.TestePratico.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmpreendimentoController : ControllerBase
    {

        private readonly ILogger<EmpreendimentoController> _logger;
        private readonly IEmpreendimentoBO empreendimentoBO;

        public EmpreendimentoController(ILogger<EmpreendimentoController> logger, IEmpreendimentoBO _empreendimentoBO)
        {
            _logger = logger;
            empreendimentoBO = _empreendimentoBO;
        }

        /// <summary>
        /// Get list all Empreendimentos
        /// </summary>
        [HttpGet]
        [Route("GetListAll")]
        public async Task<IActionResult> GetListAll()
        {
            try
            {
                var result = await empreendimentoBO.GetList();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        /// </summary>
        [HttpGet]
        [Route("GetById/{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var result = await empreendimentoBO.GetById(id);

                if (result == null)
                {
                    return NotFound($"Empreendimento com id {id} n�o encontrado.");
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Get list all Empreendimentos
        /// </summary>
        [HttpGet]
        [Route("GetList")]
        public async Task<IActionResult> GetList(
            [FromQuery] string? nome = null,
            [FromQuery] char? status = null)
        {
            try
            {
                var result = await empreendimentoBO.GetList(nome, status);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Save Empreendimento
        /// </summary>
        [HttpPost]
        [Route("Save")]
        public async Task<IActionResult> Save([FromBody] EmpreendimentoDTO empreendimento)
        {
            try
            {
                var result = await empreendimentoBO.Save(empreendimento);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Empreendimento
        /// </summary>
        [HttpPut]
        [Route("Update")]
        public async Task<IActionResult> Update([FromBody] EmpreendimentoDTO empreendimento)
        {
            try
            {
                var result = await empreendimentoBO.Update(empreendimento);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Delete Empreendimento
        /// </summary>
        [HttpDelete]
        [Route("Delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await empreendimentoBO.Delete(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }


    }
}
