﻿using Microsoft.EntityFrameworkCore;
using Monitori.TestePratico.Model.Empreendimento;
using Monitory.TestePratico.Repository;
using Monitory.TestePratico.Repository.Entity;

namespace Monitori.TestePratico.Business.Empreendimento
{
    public class EmpreendimentoBO: IEmpreendimentoBO
    {
        private readonly OrionDbContext _context;
        public EmpreendimentoBO(OrionDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Delete(int Id)
        {

            var empreendimento = new TbEmpreendimento
            {
                IdEmpreendimento = Id
            };

            _context.TbEmpreendimento.Attach(empreendimento);
            _context.TbEmpreendimento.Remove(empreendimento);

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<List<EmpreendimentoDTO>> GetList()
        {
            return await _context.TbEmpreendimento
                .Select(x => new EmpreendimentoDTO
                {
                    Id = x.IdEmpreendimento,
                    Cnpj = x.Cnpj,
                    Nome = x.Nome.ToString(),
                    Endereco = x.Endereco.ToString(),
                    Status = x.Status,
                    DataCriacao = x.DataCriacao
                })
                .ToListAsync();
        }

        public async Task<List<EmpreendimentoDTO>> GetList(string? nome = null, char? status = null)
        {
            var query = _context.TbEmpreendimento.AsQueryable();

            if (!string.IsNullOrWhiteSpace(nome))
            {
                query = query.Where(x => EF.Functions.Like(x.Nome, $"%{nome}%"));
            }

            if (status.HasValue)
            {
                query = query.Where(x => x.Status == status);
            }

            return await query
                .Select(x => new EmpreendimentoDTO
                {
                    Id = x.IdEmpreendimento,
                    Cnpj = x.Cnpj,
                    Nome = x.Nome,
                    Endereco = x.Endereco,
                    Status = x.Status,
                    DataCriacao = x.DataCriacao
                })
                .ToListAsync();
        }

        public async Task<EmpreendimentoDTO?> GetById(int id)
        {
            return await _context.TbEmpreendimento
                .Where(x => x.IdEmpreendimento == id)
                .Select(x => new EmpreendimentoDTO
                {
                    Id = x.IdEmpreendimento,
                    Cnpj = x.Cnpj,
                    Nome = x.Nome,
                    Endereco = x.Endereco,
                    Status = x.Status,
                    DataCriacao = x.DataCriacao
                })
                .FirstOrDefaultAsync();
        }


        public async Task<bool> Save(EmpreendimentoDTO empreendimentoDTO)
        {
            if (empreendimentoDTO == null)
                throw new ArgumentNullException(nameof(empreendimentoDTO));

            if (string.IsNullOrWhiteSpace(empreendimentoDTO.Nome))
                throw new Exception("Nome é obrigatório.");

            if (string.IsNullOrWhiteSpace(empreendimentoDTO.Cnpj))
                throw new Exception("CNPJ é obrigatório.");

            var cnpjExiste = await _context.TbEmpreendimento
                .AnyAsync(x => x.Cnpj == empreendimentoDTO.Cnpj);

            if (cnpjExiste)
                throw new Exception("Já existe um empreendimento cadastrado com este CNPJ.");

            var empreendimento = new TbEmpreendimento
            {
                Nome = empreendimentoDTO.Nome,
                Cnpj = empreendimentoDTO.Cnpj,
                Endereco = empreendimentoDTO.Endereco,
                Status = empreendimentoDTO.Status,
                DataCriacao = DateTime.Now
            };

            await _context.TbEmpreendimento.AddAsync(empreendimento);

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> Update(EmpreendimentoDTO empreendimentoDTO)
        {
            if (empreendimentoDTO == null)
                throw new ArgumentNullException(nameof(empreendimentoDTO));

            var empreendimento = await _context.TbEmpreendimento
                .FirstOrDefaultAsync(x => x.IdEmpreendimento == empreendimentoDTO.Id);

            if (empreendimento == null)
                return false;

            // Verifica se existe outro empreendimento com o mesmo CNPJ
            var cnpjDuplicado = await _context.TbEmpreendimento
                .AnyAsync(x => x.Cnpj == empreendimentoDTO.Cnpj
                            && x.IdEmpreendimento != empreendimentoDTO.Id);

            if (cnpjDuplicado)
                throw new Exception("Já existe um empreendimento cadastrado com este CNPJ.");

            empreendimento.Nome = empreendimentoDTO.Nome;
            empreendimento.Cnpj = empreendimentoDTO.Cnpj;
            empreendimento.Endereco = empreendimentoDTO.Endereco;
            empreendimento.Status = empreendimentoDTO.Status;

            _context.TbEmpreendimento.Update(empreendimento);

            return await _context.SaveChangesAsync() > 0;
        }
    }
}
