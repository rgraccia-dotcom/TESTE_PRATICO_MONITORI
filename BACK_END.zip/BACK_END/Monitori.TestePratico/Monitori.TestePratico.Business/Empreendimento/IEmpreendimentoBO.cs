﻿using Monitori.TestePratico.Model.Empreendimento;

namespace Monitori.TestePratico.Business
{
    public interface IEmpreendimentoBO
    {

        Task<List<EmpreendimentoDTO>> GetList();

        Task<List<EmpreendimentoDTO>> GetList(string? nome = null, char? status = null);

        Task<EmpreendimentoDTO?> GetById(int id);

        Task<bool> Save(EmpreendimentoDTO empreendimentoDTO);

        Task<bool> Delete(int Id);

        Task<bool> Update(EmpreendimentoDTO empreendimentoDTO);

    }
}
