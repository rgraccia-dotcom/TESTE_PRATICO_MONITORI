USE [DB_MONITORI]
GO

/****** Object:  Table [dbo].[TbEmpreendimento]    Script Date: 08/06/2026 01:15:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TbEmpreendimento](
	[IdEmpreendimento] [int] IDENTITY(1,1) NOT NULL,
	[Cnpj] [varchar](14) NULL,
	[Nome] [varchar](200) NULL,
	[Endereco] [varchar](300) NULL,
	[Status] [char](1) NULL,
	[DataCriacao] [datetime] NULL,
 CONSTRAINT [PK_Empreendimento] PRIMARY KEY CLUSTERED 
(
	[IdEmpreendimento] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Empreendimento_CNPJ] UNIQUE NONCLUSTERED 
(
	[Cnpj] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


