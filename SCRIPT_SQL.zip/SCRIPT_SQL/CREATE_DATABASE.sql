USE [master];
GO

CREATE DATABASE [DB_MONITORI]
ON PRIMARY
(
    NAME = N'DB_MONITORI',
    FILENAME = N'C:\Users\rgrac\DB_MONITORI.mdf',
    SIZE = 8MB,
    FILEGROWTH = 64MB
)
LOG ON
(
    NAME = N'DB_MONITORI_log',
    FILENAME = N'C:\Users\rgrac\DB_MONITORI_log.ldf',
    SIZE = 8MB,
    FILEGROWTH = 64MB
);
GO

USE [DB_MONITORI];
GO

